<!DOCTYPE HTML>
<html>
<head>
	<meta charset="UTF-8"/>
	<title>BLOG</title>
	<style>
	body {
		text-align:center;
		background-color: #00ff44;
	}
	</style>
</head>
<body>
<div id="header">
	
</div>
</body>
</html>