<!DOCTYPE html>
<html>
<head>
	<title>Blog</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>



	<div id="head">
		<h2>myBLOG</h2>
		<div id="navigation">
				<div id="log">
					<p>Hello, Admin</p>
					<p>Level of permission: Admin</p>
				</div>
			<a href="log.php">Login</a>
		</div>
	</div>
  
	<div id="article">
    
	</div>
</body>
</html>